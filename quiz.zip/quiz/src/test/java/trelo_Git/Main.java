package trelo_Git;
public class Main {
    public static void main(String[] args) {
        QuizManager quizManager = new QuizManager();
        quizManager.setupGame();
        quizManager.startGame();
    }
}
